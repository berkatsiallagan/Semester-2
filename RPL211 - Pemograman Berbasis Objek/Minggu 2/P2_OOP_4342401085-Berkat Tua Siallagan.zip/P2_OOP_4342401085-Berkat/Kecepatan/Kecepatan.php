<?php
class Kecepatan {
    // Method untuk menghitung kecepatan
    public function hitung($jarak, $waktu) {
        return $jarak / $waktu;
    }
}
