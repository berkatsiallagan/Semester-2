x = 0

y = 10

print(x)
print(y)