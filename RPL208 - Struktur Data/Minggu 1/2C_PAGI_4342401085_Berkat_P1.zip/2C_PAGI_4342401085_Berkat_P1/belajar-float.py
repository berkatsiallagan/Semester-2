x = 10.2
y = 100
z = 37.89

total = x+y+z
print(total)