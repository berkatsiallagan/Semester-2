x = 'Doni'
y = "Eka"

print(x)
print(y)

print("Nama mahasiswa 1 adalah "+x)
print(y+" adalah mahasiswa 2")
print(x +" adalah sahabat "+y)
print(x+y)