x = 232
y = 777

total = x+y

print(total)