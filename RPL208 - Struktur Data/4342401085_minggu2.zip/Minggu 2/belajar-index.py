#array dengan nama mahasiswa
mahasiswa = ["nini","nunu","lala","kaka"]
#panggil nama mahasiswa dengan nama lala
print(mahasiswa[2])