#array dengan nama mahasiswa
mahasiswa = ["nini", "nunu", "lala", "kaka"]

#mahasiswa element
mahasiswa.remove("nunu")

#tampilkan isi array mahasiswa
print(mahasiswa)