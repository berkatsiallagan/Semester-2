#array dengan nama mahasiswa
mahasiswa = ["nini","nunu","lala","kaka"]

#jumlah element pada array
x = len(mahasiswa)

#tampilkan isi array mahasiswa
print(x)