#array dengan nama mahasiswa
mahasiswa = ["nilai", "nunu", "lala", "kaka"]

#looping elemen array
for mhs in mahasiswa:

#tampilkan isi array mahasiswa
    print(mhs)