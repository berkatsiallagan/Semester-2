#arrray dengan nama mahasiswa
mahasiswa = ["nini", "nunu", "lala", "kaka"]

#menambahkan element
mahasiswa.append("tata")

#tamilkan isi array mahasiswa
print(mahasiswa)