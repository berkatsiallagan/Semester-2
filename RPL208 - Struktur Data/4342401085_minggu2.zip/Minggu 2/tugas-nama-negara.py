#array dengan nama mahasiswa 
negara = ["Malaysia","Brunei","Indonesia","Fhilipina", "Singapura", "Birma"]

#tampilkan isi array mahasiswa
print(negara)
