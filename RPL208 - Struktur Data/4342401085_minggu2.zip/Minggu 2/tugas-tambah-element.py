# Array dengan nama mahasiswa
negara = ["Malaysia", "Brunei", "Indonesia", "Fhilipina", "Singapura", "Birma"]

# Tampilkan isi array mahasiswa
print(negara)

# Menampilkan nilai array pada index ke-3
print("Negara pada index ke-3:", negara[3])