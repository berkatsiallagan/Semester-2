#array dengan nama mahasiswa
mahasiswa = ["nini","nunu","lala","kaka"]

#ubah nilai item array pertama
mahasiswa[0] = "rara"

#tampilkan isi array mahasiswa
print(mahasiswa)