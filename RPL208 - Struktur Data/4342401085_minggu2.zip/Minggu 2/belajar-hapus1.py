#array dengan nama mahasiswa
mahasiswa = ["nini", "nunu", "lala", "kaka"]

#menambahkan element
mahasiswa.pop(2)

#tampilkan isi array mahasiswa
print(mahasiswa)
