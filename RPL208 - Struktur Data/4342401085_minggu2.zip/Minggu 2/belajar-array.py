#array dengan nama mahasiswa 
mahasiswa = ["nini","nunu","lala","kaka"]

#tampilkan isi array mahasiswa
print(mahasiswa)